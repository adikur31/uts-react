export const addNoteInput = [{
    name: "title",
    title: "Title",
    type: "text"
  }, {
    name: "content",
    title: "content",
    type: "textarea"
  }]
