export default function returnData(response) {
  return response.data
}
